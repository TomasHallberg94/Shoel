# shoel-store

En enkel React-butik byggd för lyxiga sneakers.

## Starta projektet

1. Installera beroenden:
```bash
npm install
```

2. Kör lokalt:
```bash
npm run dev
```

## Distribution

Ladda upp hela projektmappen till [https://vercel.com](https://vercel.com) för att publicera direkt.
